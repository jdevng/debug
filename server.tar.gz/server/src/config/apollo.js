import { ApolloGateway, RemoteGraphQLDataSource } from "@apollo/gateway";
import { ApolloServer } from "apollo-server-express";

const { PrismaClient } = require('@prisma/client')


const gateway = new ApolloGateway({
    serviceList: [
      { 
        name: "accounts", url: process.env.ACCOUNTS_SERVICE_URL 
      }
    ],
    buildService({ url }) {
      return new RemoteGraphQLDataSource({
        url,
        willSendRequest({ request, context }) {
          console.log("User" + context.user)
          request.http.headers.set(
            "user",
            context.user ? JSON.stringify(context.user) : null
          );
        }
      });
    }
  });

const prisma_db = new PrismaClient()

const server = new ApolloServer({
    gateway,
    subscriptions: false,
    // context: (req) => ({
    //   authScope: getScope(req.headers.authorization)
    // })
    context: ({ req }) => {
      const one = 1;
        const user = req.user || null;
        console.log("Prisma: " + prisma_db);
        return { user: user, db: prisma_db, one: one};
    }
})

export default server;



